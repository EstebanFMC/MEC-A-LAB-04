import java.util.ArrayList;
public class Interfaz extends javax.swing.JFrame {
        ArrayList <Auto> lista = new ArrayList<>();
        IngresoVehiculos v1 = new IngresoVehiculos();
        TablaVehiculos2 v2 = new TablaVehiculos2();
        TablaVehiculos4 v4 = new TablaVehiculos4();
    
        public Interfaz() {
        initComponents();
        
    }

    @SuppressWarnings("unchecked")
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        SalirButtom = new javax.swing.JButton();
        IngresoButtom = new javax.swing.JButton();
        EliminarButtom = new javax.swing.JButton();
        Vehiculos2Buttom = new javax.swing.JButton();
        Vehiculos4Buttom = new javax.swing.JButton();
        CantidadButtom = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Franklin Gothic Demi", 2, 18)); // NOI18N
        jLabel1.setText("Parqueadero");

        SalirButtom.setText("Salir");
        SalirButtom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalirButtomActionPerformed(evt);
            }
        });

        IngresoButtom.setText("Ingreso De Vehículo");
        IngresoButtom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IngresoButtomActionPerformed(evt);
            }
        });

        EliminarButtom.setText("Eliminar Vehículo");
        EliminarButtom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EliminarButtomActionPerformed(evt);
            }
        });

        Vehiculos2Buttom.setText("Vehiculos de 2 ruedas");
        Vehiculos2Buttom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Vehiculos2ButtomActionPerformed(evt);
            }
        });

        Vehiculos4Buttom.setText("Vehiculos de 4 ruedas");
        Vehiculos4Buttom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Vehiculos4ButtomActionPerformed(evt);
            }
        });

        CantidadButtom.setText("Cantidad de vehículos");
        CantidadButtom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CantidadButtomActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(SalirButtom)
                    .addComponent(IngresoButtom)
                    .addComponent(jLabel1)
                    .addComponent(EliminarButtom, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Vehiculos2Buttom)
                    .addComponent(Vehiculos4Buttom)
                    .addComponent(CantidadButtom))
                .addContainerGap(39, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(IngresoButtom)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(EliminarButtom)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Vehiculos2Buttom)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Vehiculos4Buttom)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CantidadButtom)
                .addGap(29, 29, 29)
                .addComponent(SalirButtom)
                .addContainerGap(37, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void IngresoButtomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IngresoButtomActionPerformed
       
        v1.setVisible(true);
        v1.setLocationRelativeTo(null);
        dispose();
        
    }//GEN-LAST:event_IngresoButtomActionPerformed

    private void EliminarButtomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EliminarButtomActionPerformed
      
    }//GEN-LAST:event_EliminarButtomActionPerformed

    private void Vehiculos2ButtomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Vehiculos2ButtomActionPerformed
       v2.setVisible(true);
       v2.setLocationRelativeTo(null);
       dispose();
    }//GEN-LAST:event_Vehiculos2ButtomActionPerformed

    private void Vehiculos4ButtomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Vehiculos4ButtomActionPerformed
       v4.setVisible(true);
       v4.setLocationRelativeTo(null);
       dispose();
    }//GEN-LAST:event_Vehiculos4ButtomActionPerformed

    private void CantidadButtomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CantidadButtomActionPerformed
       
    }//GEN-LAST:event_CantidadButtomActionPerformed

    private void SalirButtomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalirButtomActionPerformed
        System.exit(0);
    }//GEN-LAST:event_SalirButtomActionPerformed

    
    
    
    
    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Interfaz().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton CantidadButtom;
    private javax.swing.JButton EliminarButtom;
    private javax.swing.JButton IngresoButtom;
    private javax.swing.JButton SalirButtom;
    private javax.swing.JButton Vehiculos2Buttom;
    private javax.swing.JButton Vehiculos4Buttom;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
