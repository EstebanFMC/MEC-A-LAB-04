
public class Auto {
private String placa, tipoV;
private int hora, NoVehiculo;

    public Auto(String placa, String tipoV, int hora, int NoVehiculo) {
        this.placa = placa;
        this.tipoV = tipoV;
        this.hora = hora;
       // this.NoVehiculo = NoVehiculo;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getTipoV() {
        return tipoV;
    }

    public void setTipoV(String tipoV) {
        this.tipoV = tipoV;
    }

    public int getHora() {
        return hora;
    }

    public void setHora(int hora) {
        this.hora = hora;
    }

  /*  public int getNoVehiculo() {
        return NoVehiculo;
    }

    public void setNoVehiculo(int NoVehiculo) {
        this.NoVehiculo = NoVehiculo;
    }*/



    
}
