
public class MainPrueba {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       int [] array = new Array[2];
       array.length;
    }
    
}

