import java.util.Timer;
import java.util.TimerTask;
import java.util.Queue;
import java.util.LinkedList;
public class MainPrueba {
  
  public static void main(String[] args) {
      Queue<String> cola = new LinkedList<>(); 
    //Persona persona = new Persona ("Jose", "Marin Perez", "POS", "Discapacitado", 13);
    //cola.add(persona.toString());
      cola.add("jose");
      cola.add("marta");
      System.out.println(cola);
  
     // System.out.println(persona.toSting());
    
}
}

